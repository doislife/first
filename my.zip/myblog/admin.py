from django.contrib import admin
from myblog.models import People,Article
# Register your models here.
admin.site.register(People)
admin.site.register(Article)