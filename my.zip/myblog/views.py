from django.shortcuts import render, HttpResponse
from myblog.models import People,Article

def index(request):
    tag_note = request.GET.get('tag')
    if tag_note:
        article_list = Article.objects.filter(tag=tag_note)
    else:
        article_list = Article.objects.all()
    context = {}
    blog_list = People.objects.all()
    context['article_list'] = article_list
    context['blog_list'] = blog_list
    web_page = render(request,'index.html',context)
    return web_page