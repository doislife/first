from django.shortcuts import render, HttpResponse
from first.models import Article

def index(request):
    tag_note = request.GET.get('tag')
    if tag_note:
        article_list = Article.objects.filter(tag=tag_note)
    else:
        article_list = Article.objects.all()
    context = {}
    context['article_list'] = article_list
    web_page = render(request,'index.html',context)
    return web_page
# Create your views here.
